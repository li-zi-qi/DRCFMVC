import torch.nn as nn
import torch
import torch.nn.functional as F
import numpy as np
from torch.nn.functional import normalize

class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),
            nn.ReLU(),
            nn.Linear(2000, feature_dim),
        )

    def forward(self, x):
        return self.encoder(x)

# Decoder
class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),
            nn.ReLU(),
            nn.Linear(2000, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )

    def forward(self, x):
        return self.decoder(x)

class MembershipCollector(nn.Module):
    def __init__(self, input_dim, num_clusters,p):
        super(MembershipCollector, self).__init__()
        self.p = p
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(64, num_clusters)
        )

    def forward(self, x):
        h = self.net(x)
        return self.get_norm_outputs(h)

    def get_norm_outputs(self, inputs):
        norm = torch.norm(inputs, p=self.p, dim=1, keepdim=True)
        norm = torch.clamp(norm, min=1e-10)
        outputs = inputs / norm
        outputs = torch.relu(outputs)
        outputs = outputs + 1e-10
        outputs = outputs / outputs.sum(dim=1, keepdim=True)
        return outputs
    
    
class Network(nn.Module):
    def __init__(self, view, input_size, feature_dim, high_feature_dim, class_num, lambda_f, p, device):
        super(Network, self).__init__()
        self.view = view  
        self.epsilon = 1e-10  
        self.lambda_f = lambda_f
        self.p = p
        self.num_clusters = class_num
        self.encoders = nn.ModuleList([Encoder(input_size[v], feature_dim).to(device) for v in range(view)])
        self.decoders = nn.ModuleList([Decoder(input_size[v], feature_dim).to(device) for v in range(view)])      
        self.MembershipCollectors = nn.ModuleList([MembershipCollector(feature_dim, class_num,self.p).to(device) for v in range(view)])
        self.feature_fusion_module = nn.Sequential(
            nn.Linear(self.view * feature_dim, 256),
            nn.ReLU(),
            nn.Linear(256, high_feature_dim)
        )
        self.common_information_module = nn.Sequential(
            nn.Linear(feature_dim, high_feature_dim)
        )
        
    def Fusion(self, zs, zs_gradient):
        input = torch.cat(zs, dim=1) if zs_gradient else torch.cat(zs, dim=1).detach()
        return normalize(self.feature_fusion_module(input),dim=1)


    def EvidenceUncertainty(self, membership,lambda_f): 
        self.lambda_f = lambda_f
        bpa = membership / (membership.sum(dim=1, keepdim=True) + 1e-10) 
        
        sorted_bpa, _ = torch.sort(bpa, dim=1, descending=True) 
        cumulative = torch.cumsum(sorted_bpa, dim=1) 
        belief = torch.zeros_like(bpa) 
        for k in range(bpa.size(1)): 
            belief[:, k] = cumulative[:, k] * (1 - self.lambda_f * k) 
        
        sorted_indices = torch.argsort(bpa, dim=1, descending=True) 
        inverse_sorted_indices = torch.argsort(sorted_indices, dim=1) 
        plausibility = torch.gather(belief, 1, inverse_sorted_indices) 
        uncertainty = (plausibility - belief).mean(dim=1, keepdim=True) 
        uncertainty = uncertainty.squeeze().unsqueeze(1) 
        
        return uncertainty.clamp(min=0, max=1) 

    def forward(self, xs):
        xrs = []  
        zs = []    
        rs = []
        Memberships = []  
        Credibilitys = []  
        Uncertaintys = []  
        
        for v in range(self.view):
            x = xs[v]
            z = self.encoders[v](x)
            xr = self.decoders[v](z)
            r = normalize(self.common_information_module(z),dim=1)
            membership = self.MembershipCollectors[v](z)
            uncertainty = self.EvidenceUncertainty(membership,self.lambda_f)
            zs.append(z)
            xrs.append(xr)
            rs.append(r)
            Memberships.append(membership)
            Uncertaintys.append(uncertainty)
        
        F = self.Fusion(zs,zs_gradient = True)
        weights = []
        for view in range(self.view):
            conflict_degree = 0.0
            for v in range(self.view):
                if v != view:
                    conflict_degree += self.get_ConflictDegree(Memberships[view], Memberships[v]) * (1 / (self.view - 1))

            weight = (1 - Uncertaintys[view]) / (1 + conflict_degree) + self.epsilon
            weights.append(weight)
        
        Weights = torch.stack(weights)  
        Weights = torch.softmax(Weights, dim=0)
        
        return xrs, zs, rs, F , Memberships, Weights

    def get_ConflictDegree(self, vector1, vector2, eps=1e-8):
        p = F.softmax(vector1, dim=1)  
        q = F.softmax(vector2, dim=1)
        m = 0.5 * (p + q)
        kl_p = torch.sum(p * torch.log((p + eps) / (m + eps)), dim=1)  
        kl_q = torch.sum(q * torch.log((q + eps) / (m + eps)), dim=1)  
        js_div = 0.5 * (kl_p + kl_q)
        conflict_degree = js_div / torch.log(torch.tensor(2.0))

        return conflict_degree.view(-1, 1)
