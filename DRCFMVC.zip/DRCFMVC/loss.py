import torch
import torch.nn as nn
import math
import torch.nn.functional as F
from sklearn.cluster import KMeans

class Loss(nn.Module):
    def __init__(self, batch_size, class_num, temperature_f, device):
        super(Loss, self).__init__()
        self.batch_size = batch_size
        self.class_num = class_num
        self.temperature_f = temperature_f
        self.device = device
        self.mask = self.mask_correlated_samples(batch_size)
        self.similarity = nn.CosineSimilarity(dim=2)
        self.criterion = nn.CrossEntropyLoss(reduction="sum")

    def mask_correlated_samples(self, N):
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(N//2):
            mask[i, N//2 + i] = 0
            mask[N//2 + i, i] = 0
        mask = mask.bool()
        
        return mask

    def forward_feature(self, h_i, h_j, weight=None):
        N = self.batch_size
        similarity_matrix = torch.matmul(h_i, h_j.T) / self.temperature_f
        positives = torch.diag(similarity_matrix) 
        mask = torch.ones((N, N), device=self.device).fill_diagonal_(0).bool()        
        nominator = torch.exp(positives)
        denominator = torch.sum(torch.exp(similarity_matrix) * mask, dim=1)  
        loss_partial = -torch.log(nominator / denominator) 

        if weight is not None:
            weight = weight.squeeze()  
            loss_partial = loss_partial * weight        
        loss = torch.sum(loss_partial) / N  
        
        return loss




    
